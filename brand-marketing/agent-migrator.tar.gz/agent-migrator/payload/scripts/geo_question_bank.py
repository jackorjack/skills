#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 GEO 关键词矩阵中提取某一分类的标题清单（标题只从清单中选，不再另写）。

用法：
    python3 scripts/geo_question_bank.py                      # 列出五类及各 50 条
    python3 scripts/geo_question_bank.py 问题类                 # 只看问题类 50 条
    python3 scripts/geo_question_bank.py 业务类 --limit 10      # 别名映射 + 限制条数
    python3 scripts/geo_question_bank.py 业务类 --with-flags    # 标注决策/比选意图条目
    python3 scripts/geo_question_bank.py --decision 产品词       # 只列决策/比选型条目
    python3 scripts/geo_question_bank.py 业务类 --json          # 输出序号+文本的 JSON

输出编号一律使用矩阵原始编号（1–50），与 wiki 文件逐条对齐，便于用户按序号选标题。
矩阵路径默认 wiki/GEO关键词矩阵.md（相对工作区根目录）。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

MATRIX = Path("wiki/GEO关键词矩阵.md")
WORKSPACE = Path(__file__).resolve().parent.parent


def resolve_matrix(arg: str | None) -> Path:
    """支持任意 cwd：先按传入路径，再按工作区根目录回退。"""
    if arg:
        p = Path(arg)
        if p.is_absolute() or p.exists():
            return p
    for cand in (Path(MATRIX), WORKSPACE / MATRIX):
        if cand.exists():
            return cand
    return Path(MATRIX)

# AGENTS.md 的选题分类 -> 矩阵章节
CATEGORY_MAP = {
    "业务类": "产品词类",
    "品牌类": "品牌词类",
    "地域类": "地域词类",
    "人群场景类": "人群场景类",
    "问题类": "问题类",
}

# 决策/比选型意图：只适合榜单排名类角度
DECISION_RE = re.compile(r"哪家|排名|推荐|靠谱|口碑|最强|最好|怎么样|值得")


def load_section_four(text: str) -> dict[str, list[tuple[int, str]]]:
    """解析第四节，返回 {分类: [(原始编号, 标题), ...]}。"""
    lines = text.splitlines()
    try:
        start = next(i for i, l in enumerate(lines) if l.startswith("# 四、"))
    except StopIteration:
        raise SystemExit("未找到「# 四、GEO问题/标题全集」章节，矩阵格式可能已变更")
    out: dict[str, list[tuple[int, str]]] = {}
    cur = None
    for line in lines[start:]:
        m = re.match(r"^## （[一二三四五]）(.+?)问题（\d+条）", line)
        if m:
            cur = m.group(1)
            out[cur] = []
            continue
        m = re.match(r"^\s*(\d+)\.\s*(.+?)\s*$", line)
        if m and cur:
            out[cur].append((int(m.group(1)), m.group(2)))
    return out


def select(items: list[tuple[int, str]], args) -> list[tuple[int, str]]:
    if args.decision:
        items = [(n, t) for n, t in items if DECISION_RE.search(t)]
    if args.limit:
        items = items[: args.limit]
    return items


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("category", nargs="?", help="业务类/品牌类/地域类/人群场景类/问题类，留空则全部")
    ap.add_argument("--matrix", default=str(MATRIX))
    ap.add_argument("--limit", type=int, default=0, help="每类最多输出条数，0 为不限制")
    ap.add_argument("--decision", action="store_true", help="只输出决策/比选型条目")
    ap.add_argument("--with-flags", action="store_true", help="给决策/比选型条目加注提示")
    ap.add_argument("--json", action="store_true", help="输出 [{index,title}] JSON")
    args = ap.parse_args()

    path = resolve_matrix(args.matrix if args.matrix != str(MATRIX) else None)
    if not path.exists():
        raise SystemExit(f"矩阵文件不存在：{path}")

    bank = load_section_four(path.read_text(encoding="utf-8"))
    if not bank:
        raise SystemExit("问题表为空")

    targets = list(bank)
    if args.category:
        key = CATEGORY_MAP.get(args.category, args.category)
        if key not in bank and f"{key}类" in bank:
            key = f"{key}类"
        if key not in bank:
            raise SystemExit(f"未找到分类「{args.category}」，可选：{', '.join(bank)}")
        targets = [key]

    if args.json:
        payload = {
            k: [{"index": n, "title": t} for n, t in select(bank[k], args)]
            for k in targets
        }
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    total = 0
    for k in targets:
        items = select(bank[k], args)
        total += len(items)
        alias = ""
        if args.category and args.category != k:
            alias = f"（{args.category}对应）"
        print(f"## {k}{alias}（{len(items)} 条）")
        for n, t in items:
            flag = ""
            if args.with_flags and DECISION_RE.search(t):
                flag = "  ← 决策/比选意图，仅配榜单排名类"
            print(f"{n:>2}. {t}{flag}")
        print()
    print(f"合计 {total} 条（源：{path}）", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
