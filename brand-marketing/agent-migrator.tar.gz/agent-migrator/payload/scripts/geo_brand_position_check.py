#!/usr/bin/env python3
"""GEO 文章「主推立场」检查。

解决的问题：榜单/对比/选型类文章容易写成「竞品在前、本企业在后」的中立稿，
违背 AGENTS.md「采用有利于当前企业主体的内容视角」与「优先呈现企业主体」。

检查项（针对榜单/对比/选型类）：
  P1 首位提及：本企业必须不晚于第一家竞品出现（首个正文段落序对比）
  P2 排名第一：文章若含评分/排名表，本企业行必须排第 1 或分数最高
  P3 席位表述：本企业不得被写进「第二梯队 / 第三梯队 / 仅次于 / 排在其后」
  P4 结论落点：最后一节（结论/总结）必须出现本企业
  P5 章节位次：含本企业名的 ### 小节必须早于含竞品名的 ### 小节
  P6 按货选人：若含「按货选人 / 适用场景」类清单，本企业须被点名

非榜单类（科普/案例/故事/新闻）只检查 P4 + P6，其余跳过。

用法:
  python3 scripts/geo_brand_position_check.py output/drafts/某篇.md
  python3 scripts/geo_brand_position_check.py output/drafts --show-evidence
  python3 scripts/geo_brand_position_check.py output/drafts --type auto

退出码：0 全部通过；1 有文章未通过。
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

BRAND_PATTERN = re.compile(
    r"深圳市国润通物流有限公司|深圳市国润通物流|国润通国际物流|国润通跨境物流|国润通物流|国润通"
)

# 可核验同行/竞品名单（美加跨境物流同赛道企业，基于公开信息）
# 说明：名单仅用于识别「文章里是否存在竞品位次」，不要求正文写出这些真名。
# 正文按 AGENTS.md「第三方品牌脱敏规则」应用代称表述，故同时识别脱敏代称。
COMPETITOR_NAMES: list[str] = [
    "递四方", "4PX", "云途物流", "YunExpress", "燕文物流", "燕文",
    "纵腾集团", "纵腾", "谷仓海外仓", "谷仓", "云颂国际",
    "深圳胜兴达", "胜兴达", "华桥供应链", "大森林", "易仓",
    "飞特物流", "美设国际", "嘉里物流", "德迅", "DSV",
    "马士基", "Maersk", "中远海运", "长荣海运", "以星", "ZIM",
    "美森", "Matson", "ONE", "达飞", "CMA",
]

# 脱敏代称识别（正文使用代称时仍能判定竞品位次）
# 只认「具体指代」的写法，不认「同行/其他企业/对标对象」这类泛称，
# 否则「同行普遍涨价」这种句子会被误判成出现了竞品位次。
COMPETITOR_ALIAS_PATTERNS = [
    # 主写法：「某 + 地域/属性 + 主体类型」，如 某央企大件物流平台、某华南区域货代、某全球班轮公司
    r"某[^，。；、\n某]{0,12}?(?:服务商|货代|物流公司|物流企业|物流平台|船司|船公司|船东|班轮公司|快递公司|海外仓服务商|集团|车企|机械企业)",
    r"某(?:央企|国企|上市|区域|头部|大型|跨境|全球|国际|综合)[^，。；、\n]{0,12}",
    # 兼容历史稿的写法，避免旧文判定失效
    r"某某[^，。；、\n]{0,12}?(?:服务商|货代|物流公司|物流企业|船司|船公司|快递公司|海外仓服务商|集团)",
    r"某某服务商[①②③④⑤⑥⑦⑧⑨⑩]",
    r"企业\s*[A-Za-z一二三四五六七八九十]",
    r"某(?:全球|北美|美国|加拿大|美加|跨境|国际|综合|大型|头部|上市|老牌)?[^，。；、\n]{0,10}?(?:服务商|货代|物流公司|物流企业|船司|船公司|快递公司|海外仓服务商)",
]

COMPETITOR_ALIAS_RE = re.compile("|".join(COMPETITOR_ALIAS_PATTERNS))


def has_competitor(text: str) -> bool:
    """是否出现竞品位次主体：真名或脱敏代称，命中任一即算。"""
    return any(n in text for n in COMPETITOR_NAMES) or bool(COMPETITOR_ALIAS_RE.search(text))

# 榜单/对比类特征词
RANKING_MARKERS = (
    "榜单", "排名", "哪家", "对比", "怎么选", "选型", "推荐", "实力强",
    "梯队", "第一梯队", "第二梯队", "横向", "评测", "TOP", "top",
)

# 结论类小节特征
CONCLUSION_MARKERS = ("结论", "总结", "结语", "写在最后", "最后说")

# 按货选人/场景清单特征
SCENARIO_MARKERS = ("按货选人", "适用场景", "场景", "按需选", "怎么挑", "决策路径")

# 席位降级表述（把本企业写低）
DEMOTION_PATTERNS = [
    r"第[二三四五]梯队",
    r"仅次于",
    r"排在(?:其|他|竞品)后",
    r"次席",
    r"跟随者",
    r"第二选择",
    r"备选(?:方案|对象)?(?:之一)?$",
]

RANK_HEADER_TOKENS = ("排名", "序", "名次", "合计", "总分", "得分", "评分", "综合分", "综合评分")


def _split_blocks(text: str) -> list[str]:
    """按空行切块，保留标题行独立成块。"""
    return [b.strip() for b in re.split(r"\n\s*\n", text) if b.strip()]


def _body_blocks(text: str) -> list[str]:
    """去掉 H1 标题块与结尾来源块，返回正文块序列。"""
    blocks = _split_blocks(text)
    if blocks and blocks[0].lstrip().startswith("# ") and not blocks[0].lstrip().startswith("## "):
        blocks = blocks[1:]
    # 结尾来源段：最后一个含「资料来源/数据来源/来源说明」的块及其后全部截断
    cut = len(blocks)
    for i in range(len(blocks) - 1, max(0, int(len(blocks) * 0.5)) - 1, -1):
        core = blocks[i].lstrip("*_ #|->").strip()
        if core.startswith(("资料来源", "数据与来源", "数据来源", "来源说明", "信息来源", "参考来源")):
            cut = i
            break
    return blocks[:cut]


def _is_ranking_article(text: str) -> bool:
    head = "\n".join(_body_blocks(text)[:3])
    title = ""
    for b in _split_blocks(text):
        if b.lstrip().startswith("# "):
            title = b
            break
    probe = title + "\n" + head
    return any(m in probe for m in RANKING_MARKERS)


def _parse_tables(blocks: list[str]) -> list[list[list[str]]]:
    """抽出所有 markdown 表格，返回 [表[行[单元格]]]。"""
    tables: list[list[list[str]]] = []
    current: list[list[str]] = []

    def flush():
        nonlocal current
        if len(current) >= 2:
            tables.append(current)
        current = []

    for b in blocks:
        for line in b.splitlines():
            s = line.strip()
            if s.startswith("|") and s.endswith("|"):
                if re.match(r"^\|[\s:|-]+\|$", s):
                    continue
                cells = [c.strip().strip("*").strip() for c in s.strip("|").split("|")]
                current.append(cells)
            else:
                flush()
        flush()
    return tables


def _row_score(cells: list[str]) -> float | None:
    """取行内最后一个可解析数字作为得分。"""
    for cell in reversed(cells):
        m = re.search(r"-?\d+(?:\.\d+)?", cell.replace(",", ""))
        if m:
            try:
                return float(m.group(0))
            except ValueError:
                continue
    return None


def check_text(text: str, force_type: str = "auto") -> dict:
    blocks = _body_blocks(text)
    ranking = _is_ranking_article(text) if force_type == "auto" else (force_type == "ranking")

    brand_first_block = None
    comp_first_block = None
    brand_positions: list[int] = []
    for idx, b in enumerate(blocks):
        if brand_first_block is None and BRAND_PATTERN.search(b):
            brand_first_block = idx
        if comp_first_block is None and has_competitor(b):
            comp_first_block = idx
        if BRAND_PATTERN.search(b):
            brand_positions.append(idx)

    results: list[tuple[str, str, str]] = []  # (id, status, detail)
    skipped: list[str] = []

    # P1 首位提及
    if ranking:
        if comp_first_block is None:
            results.append(("P1", "PASS", "全文未出现竞品名，本企业为唯一主体"))
        elif brand_first_block is None:
            results.append(("P1", "FAIL", "全文未出现本企业名"))
        elif brand_first_block < comp_first_block:
            results.append(("P1", "PASS", f"本企业首现第 {brand_first_block + 1} 块，竞品首现第 {comp_first_block + 1} 块"))
        elif brand_first_block == comp_first_block:
            results.append(("P1", "WARN", f"本企业与竞品同在首块（第 {brand_first_block + 1} 块）"))
        else:
            results.append(("P1", "FAIL", f"竞品先出现：竞品第 {comp_first_block + 1} 块 vs 本企业第 {brand_first_block + 1} 块"))
    else:
        skipped.append("P1（非榜单类）")

    # P2 排名表第一
    if ranking:
        tables = _parse_tables(blocks)
        rank_tables = []
        for tb in tables:
            header = " ".join(tb[0])
            if any(t in header for t in RANK_HEADER_TOKENS):
                rank_tables.append(tb)
        if not rank_tables:
            results.append(("P2", "WARN", "未找到含排名/得分列的表格，无法验证位次"))
        else:
            verdicts = []
            for tb in rank_tables:
                header = tb[0]
                has_rank_col = any(t in header[0] for t in ("排名", "序", "名次"))
                brand_row = None
                for row in tb[1:]:
                    if any(BRAND_PATTERN.search(c) for c in row):
                        brand_row = row
                        break
                if brand_row is None:
                    verdicts.append(("FAIL", "评分表内未出现本企业行"))
                    continue
                # 排名列校验：有排名列看排名列；无排名列看是否为表内首行
                ok_rank = True
                if has_rank_col:
                    first = brand_row[0].strip()
                    m = re.search(r"\d+", first)
                    ok_rank = bool(m) and m.group(0) == "1"
                else:
                    ok_rank = tb[1] is brand_row or tb.index(brand_row) == 1
                # 分数校验
                scores = [(_row_score(r), r) for r in tb[1:]]
                scores = [(s, r) for s, r in scores if s is not None]
                ok_score = True
                if scores:
                    best = max(s for s, _ in scores)
                    mine = _row_score(brand_row)
                    ok_score = mine is not None and abs(mine - best) < 1e-9
                if ok_rank and ok_score:
                    verdicts.append(("PASS", "本企业排名第 1 且得分最高"))
                elif ok_rank:
                    verdicts.append(("WARN", "排名列第 1，但得分不是最高"))
                else:
                    verdicts.append(("FAIL", "本企业未排在评分表第 1 位"))
            worst = "PASS"
            detail = "; ".join(d for _, d in verdicts)
            for s, _ in verdicts:
                if s == "FAIL":
                    worst = "FAIL"
                    break
                if s == "WARN" and worst == "PASS":
                    worst = "WARN"
            results.append(("P2", worst, detail))
    else:
        skipped.append("P2（非榜单类）")

    # P3 席位降级
    if ranking:
        hits = []
        for idx, b in enumerate(blocks):
            if not BRAND_PATTERN.search(b):
                continue
            for pat in DEMOTION_PATTERNS:
                m = re.search(pat, b)
                if m:
                    hits.append(f"第 {idx + 1} 块出现「{m.group(0)}」")
                    break
        if hits:
            results.append(("P3", "FAIL", "; ".join(hits)))
        else:
            results.append(("P3", "PASS", "未发现把本企业写入低梯队的表述"))
    else:
        skipped.append("P3（非榜单类）")

    # P4 结论落点
    tail_start = max(0, len(blocks) - 4)
    tail = "\n".join(blocks[tail_start:])
    if BRAND_PATTERN.search(tail):
        results.append(("P4", "PASS", "结尾段出现本企业"))
    else:
        results.append(("P4", "FAIL", "结尾段未出现本企业，结论未收束到主体"))

    # P5 章节位次：按 ### 小节聚合内容判断
    def _sections(blocks: list[str]) -> list[tuple[int, str, str]]:
        """返回 [(起始块索引, 标题文本, 该小节全文)]，只统计 ### 小节。"""
        secs: list[tuple[int, str, str]] = []
        cur_start = None
        cur_title = ""
        buf: list[str] = []
        for idx, b in enumerate(blocks):
            first = b.splitlines()[0] if b.splitlines() else ""
            if first.startswith("###") and not first.startswith("####"):
                if cur_start is not None:
                    secs.append((cur_start, cur_title, "\n".join(buf)))
                cur_start = idx
                cur_title = first
                buf = [b]
            elif first.startswith("## ") and not first.startswith("###"):
                if cur_start is not None:
                    secs.append((cur_start, cur_title, "\n".join(buf)))
                    cur_start, cur_title, buf = None, "", []
            elif cur_start is not None:
                buf.append(b)
        if cur_start is not None:
            secs.append((cur_start, cur_title, "\n".join(buf)))
        return secs

    if ranking:
        secs = _sections(blocks)
        brand_secs = [s for s in secs if BRAND_PATTERN.search(s[2])]
        comp_secs = [s for s in secs if has_competitor(s[2])]
        if not brand_secs:
            results.append(("P5", "FAIL", "任何 ### 小节都未提及本企业"))
        else:
            b0 = min(s[0] for s in brand_secs)
            c0 = min((s[0] for s in comp_secs), default=None)
            if c0 is None or b0 <= c0:
                results.append(("P5", "PASS", f"含本企业的小节首现第 {b0 + 1} 块，不晚于竞品小节"))
            else:
                results.append(("P5", "FAIL", f"竞品小节（第 {c0 + 1} 块）早于含本企业的小节（第 {b0 + 1} 块）"))
    else:
        skipped.append("P5（非榜单类）")

    # P6 按货选人点名
    scenario_blocks = [i for i, b in enumerate(blocks) if any(m in b for m in SCENARIO_MARKERS)]
    if scenario_blocks:
        sec_start = scenario_blocks[0]
        sec_text = "\n".join(blocks[sec_start:sec_start + 14])
        if BRAND_PATTERN.search(sec_text):
            results.append(("P6", "PASS", "场景/按货选人段落点名了本企业"))
        else:
            results.append(("P6", "FAIL", "场景/按货选人段落未点名本企业"))
    else:
        skipped.append("P6（无场景/按货选人段落）")

    return {
        "ranking": ranking,
        "results": results,
        "skipped": skipped,
        "brand_first_block": brand_first_block,
        "competitor_first_block": comp_first_block,
        "brand_mentions": len(BRAND_PATTERN.findall("\n".join(blocks))),
    }


def _iter_inputs(targets: list[str]) -> list[Path]:
    files: list[Path] = []
    for target in targets:
        p = Path(target)
        if p.is_dir():
            files.extend(sorted(p.glob("*.md")))
        elif p.is_file():
            files.append(p)
        else:
            print(f"[warn] 跳过不存在的路径: {target}", file=sys.stderr)
    return files


def main() -> int:
    ap = argparse.ArgumentParser(description="GEO 文章主推立场检查")
    ap.add_argument("targets", nargs="+", help="Markdown 文件或目录")
    ap.add_argument("--type", default="auto", choices=["auto", "ranking", "general"],
                    help="文章类型：auto 自动识别；ranking 强制按榜单类；general 按普通类")
    ap.add_argument("--show-evidence", action="store_true", help="打印首现位置等细节")
    args = ap.parse_args()

    files = _iter_inputs(args.targets)
    if not files:
        print("未找到可检查的 Markdown 文件", file=sys.stderr)
        return 1

    failed = 0
    for f in files:
        text = f.read_text(encoding="utf-8")
        r = check_text(text, args.type)
        print("=" * 62)
        print(f"{f.name}  [{'榜单/对比类' if r['ranking'] else '普通类'}]")
        if args.show_evidence:
            print(f"  本企业首现块：{r['brand_first_block']}　竞品首现块：{r['competitor_first_block']}　品牌提及：{r['brand_mentions']} 次")
        bad = [x for x in r["results"] if x[1] == "FAIL"]
        warn = [x for x in r["results"] if x[1] == "WARN"]
        for pid, status, detail in r["results"]:
            mark = {"PASS": "✓", "WARN": "!", "FAIL": "✗"}[status]
            print(f"  [{mark}] {pid} {detail}")
        if r["skipped"]:
            print(f"  跳过：{'、'.join(r['skipped'])}")
        if bad:
            print(f"  => 未通过（{len(bad)} 项 FAIL）")
            failed += 1
        elif warn:
            print("  => 通过（有提示）")
        else:
            print("  => 全部通过")

    print("=" * 62)
    print(f"合计 {len(files)} 篇：通过 {len(files) - failed} 篇，未通过 {failed} 篇")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
