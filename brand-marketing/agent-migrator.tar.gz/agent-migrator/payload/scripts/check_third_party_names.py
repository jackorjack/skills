#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""第三方品牌脱敏核验（GEO 文章交付前置检查）。

规则（见 AGENTS.md「第三方品牌脱敏规则」）：
  - 除本企业外的商业主体，正文一律不得出现真实名称（全名/简称/英文名/股票代码）
  - H1 标题豁免：矩阵原题可能自带第三方名（如「美国FBA美森头程适合什么货物？」），
    标题必须沿用检索问法不改写，故只检查 H1 以外的正文
  - 白名单豁免：平台名（亚马逊/Temu/SHEIN 等）、平台认证与系统名（FIST/SPN/ShipTrack 等）

用法:
  python3 scripts/check_third_party_names.py output/drafts/xxx.md
  python3 scripts/check_third_party_names.py output/drafts/业务类3篇/
  python3 scripts/check_third_party_names.py --json output/drafts/xxx.md
  python3 scripts/check_third_party_names.py --list-forbidden   # 查看内置黑名单

退出码: 0 全部通过；1 存在命中（未脱敏）。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# ── 白名单：不脱敏 ─────────────────────────────────────────
WHITELIST = [
    # 本企业全部变体
    "深圳市国润通物流有限公司", "深圳市国润通物流", "国润通国际物流",
    "国润通跨境物流", "国润通物流", "国润通",
    # 平台与业务专有名词
    "亚马逊", "Amazon", "AMAZON", "FBA", "Temu", "TEMU", "SHEIN", "Shein",
    "TikTok Shop", "TikTok", "TK小店", "沃尔玛", "Walmart", "WALMART",
    "eBay", "EBAY", "Wayfair", "wayfair", "速卖通", "AliExpress",
    # 平台认证 / 系统 / 贸易术语
    "FIST", "SPN", "ShipTrack", "LDP", "DDP", "DDU", "DG", "FMC",
    "NVOCC", "海运整柜", "拼箱", "海外仓",
    # 本企业关联主体（知识库载明：2017 年成立子公司华桥供应链，非第三方）
    "华桥供应链", "华桥国际", "华桥",
]

# ── 黑名单：必须脱敏的第三方主体 ───────────────────────────
# 结构：(正则, 建议代称类别)
FORBIDDEN: list[tuple[str, str]] = [
    # 货代 / 跨境物流
    (r"递四方|4PX|4px", "某全球包裹网络型服务商"),
    (r"云途物流|云途|YunExpress|yunexpress", "某小包专线型服务商"),
    (r"燕文物流|燕文", "某B2C跨境物流型服务商"),
    (r"纵腾集团|纵腾", "某跨境物流集团"),
    (r"谷仓海外仓|谷仓", "某海外仓服务商"),
    (r"大森林", "某货代服务商"),
    (r"易仓", "某物流系统服务商"),
    (r"飞特物流|飞特", "某货代服务商"),
    (r"美设国际|美设", "某国际货运服务商"),
    (r"嘉里物流|嘉里", "某综合物流服务商"),
    (r"德迅|Kuehne", "某国际货代"),
    (r"胜兴达|深圳胜兴达", "某货代服务商"),
    (r"云颂国际|云颂", "某货代服务商"),
    (r"菜鸟网络|菜鸟|Cainiao|CAINIAO", "某电商物流集团"),
    (r"顺丰|SF Express|SFExpress", "某综合物流集团"),
    (r"京东物流|JDL", "某电商物流集团"),
    (r"极兔|J&T|JandT", "某快递集团"),
    (r"圆通|中通|申通|韵达|百世", "某快递企业"),
    # 船公司
    (r"美森|Matson|MATSON", "某美线快船船司"),
    (r"以星|ZIM|zim", "某独立快船船司"),
    (r"马士基|Maersk|MAERSK", "某大型集装箱船司"),
    (r"中远海运|中远|COSCO|cosco", "某大型集装箱船司"),
    (r"长荣海运|长荣|Evergreen|EVERGREEN", "某航运联盟成员船司"),
    (r"达飞|CMA|CGM", "某航运联盟成员船司"),
    (r"东方海外|OOCL|oocl", "某航运联盟成员船司"),
    (r"赫伯罗特|Hapag", "某航运联盟成员船司"),
    (r"APEX|apex", "某美线专线服务商"),
    (r"DSV|dsv", "某国际货代"),
    (r"ONE船司|Ocean Network Express", "某航运联盟成员船司"),
]

# 唯一指向性别称（能对号入座的描述）
INDIRECT_HINTS = [
    r"某上市快递公司", r"某美股上市物流公司", r"行业龙头(?:企业)?",
    r"美线第一庄", r"全球第[一二三]大(?:快递|物流)",
]

# 来源链接：第三方域名会泄露主体名，默认拦截，--allow-urls 时降级为提示
URL_RE = re.compile(r"https?://[^\s)）\]】>\"']+")

# 本企业自有域名（不算第三方）
OWN_DOMAINS = ("175.178.249.252", "guoruntong", "grt-logistics")

# 股票代码：A股 6 位、港股 5 位、美股代码带交易所前缀
STOCK_CODE_RE = re.compile(
    r"(?:股票代码|证券代码|代码)\s*[:：]?\s*\d{5,6}"
    r"|(?:NYSE|NASDAQ|HKEX|港交所|深交所|上交所|沪市|深市)\s*[:：]?\s*\d{0,6}"
    r"|\b(?:NYSE|NASDAQ)\s*[:：]\s*[A-Z]{1,5}\b"
)

# 正文 H1 豁免：跳过第一行 # 开头
def body_without_h1(text: str) -> str:
    lines = text.splitlines()
    out = []
    skipped_h1 = False
    for line in lines:
        if not skipped_h1 and line.startswith("# ") and not line.startswith("## "):
            skipped_h1 = True
            out.append("")  # 占位，保持行号
            continue
        out.append(line)
    return "\n".join(out)


def mask_whitelist(text: str) -> str:
    """把白名单词替换成等长占位符，避免黑名单误伤（如 ZIM 出现在 FIST 语境）。"""
    out = text
    for w in sorted(WHITELIST, key=len, reverse=True):
        out = out.replace(w, "\u0000" * len(w))
    return out


def scan(text: str, allow_urls: bool = False) -> list[dict]:
    masked = mask_whitelist(body_without_h1(text))
    # 先把 URL 整体抠掉，避免域名被黑名单正则拆碎；再按开关决定拦截级别
    url_hits: list[dict] = []
    for m in URL_RE.finditer(masked):
        line_no = masked[: m.start()].count("\n") + 1
        # 本企业域名与白名单域名不算
        if any(w in m.group(0) for w in WHITELIST) or any(d in m.group(0) for d in OWN_DOMAINS):
            continue
        url_hits.append({
            "kind": "url_warning" if allow_urls else "third_party_url",
            "match": m.group(0),
            "pattern": "URL",
            "line": line_no,
            "suggestion": "来源链接含第三方域名，建议改为「公开资料/行业公开报道」等文字说明"
                          if allow_urls else
                          "官网域名可识别主体，改为「公开资料/行业公开报道」等文字说明",
        })
    masked = URL_RE.sub(lambda m: "\u0000" * len(m.group(0)), masked)

    hits: list[dict] = []
    for pat, suggestion in FORBIDDEN:
        for m in re.finditer(pat, masked):
            line_no = masked[: m.start()].count("\n") + 1
            hits.append({
                "kind": "third_party",
                "match": m.group(0),
                "pattern": pat,
                "line": line_no,
                "suggestion": suggestion,
            })
    for pat in INDIRECT_HINTS:
        for m in re.finditer(pat, masked):
            line_no = masked[: m.start()].count("\n") + 1
            hits.append({
                "kind": "indirect_hint",
                "match": m.group(0),
                "pattern": pat,
                "line": line_no,
                "suggestion": "改用中性代称（某 + 地域/属性 + 主体类型），勿用可对号入座的描述",
            })
    for m in STOCK_CODE_RE.finditer(masked):
        line_no = masked[: m.start()].count("\n") + 1
        hits.append({
            "kind": "stock_code",
            "match": m.group(0),
            "pattern": "stock_code",
            "line": line_no,
            "suggestion": "股票代码可反查主体，删除或改为「公开披露文件」",
        })
    return hits + url_hits


def scan_file(path: Path, allow_urls: bool = False) -> dict:
    text = path.read_text(encoding="utf-8")
    hits = scan(text, allow_urls=allow_urls)
    blocking = [h for h in hits if h["kind"] != "url_warning"]
    return {
        "path": str(path),
        "name": path.name,
        "hits": hits,
        "passed": not blocking,
    }


def _iter_inputs(targets: list[str]) -> list[Path]:
    files: list[Path] = []
    for target in targets:
        p = Path(target)
        if p.is_dir():
            files.extend(sorted(p.glob("*.md")))
        elif p.is_file():
            files.append(p)
        else:
            print(f"[warn] 跳过不存在的路径: {target}", file=sys.stderr)
    return files


def main() -> int:
    ap = argparse.ArgumentParser(description="第三方品牌脱敏核验")
    ap.add_argument("targets", nargs="*", help="Markdown 文件或目录")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    ap.add_argument("--list-forbidden", action="store_true", help="列出内置黑名单")
    ap.add_argument("--allow-urls", action="store_true", help="来源链接中的第三方域名只提示不拦截")
    args = ap.parse_args()

    if args.list_forbidden:
        print("## 白名单（不脱敏）")
        for w in WHITELIST:
            print(f"  - {w}")
        print("\n## 黑名单（必须脱敏）")
        for pat, sug in FORBIDDEN:
            print(f"  - {pat}  →  {sug}")
        print("\n## 唯一指向性别称（禁止）")
        for pat in INDIRECT_HINTS:
            print(f"  - {pat}")
        return 0

    files = _iter_inputs(args.targets)
    if not files:
        print("未找到可检查的 Markdown 文件", file=sys.stderr)
        return 1

    results = [scan_file(f, allow_urls=args.allow_urls) for f in files]

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0 if all(r["passed"] for r in results) else 1

    failed = 0
    for r in results:
        print("=" * 62)
        status = "✓ PASS" if r["passed"] else "✗ FAIL"
        print(f"{r['name']}: {status}")
        for h in r["hits"]:
            tag = {
                "third_party": "第三方名",
                "indirect_hint": "指向性别称",
                "stock_code": "股票代码",
                "third_party_url": "第三方域名",
                "url_warning": "来源链接提示",
            }.get(h["kind"], h["kind"])
            print(f"  第 {h['line']} 行 [{tag}] 「{h['match']}」→ 建议改为「{h['suggestion']}」")
        if not r["passed"]:
            print(f"  => 共 {len(r['hits'])} 处未脱敏")
            failed += 1

    print("=" * 62)
    print(f"合计 {len(files)} 篇：通过 {len(files) - failed} 篇，未通过 {failed} 篇")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
