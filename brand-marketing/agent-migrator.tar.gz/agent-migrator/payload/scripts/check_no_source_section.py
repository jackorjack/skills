#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""结尾来源章节核验（GEO 文章交付前置检查）。

规则（见 AGENTS.md「执行规则」）：
  - 文章结尾不得出现独立的「资料来源 / 参考来源 / 数据来源 / 参考文献 / 核验说明」章节或段落
  - 可核验性改为正文内就近标注（「据其公开年报」「据平台官方说明」等）

检测范围：
  - Markdown 标题（## / ### 等）以来源类词汇开头
  - 独立成行的加粗来源标签（**资料来源：** ...）
  - 文末纯文本来源清单行（「资料来源：」开头）

不检测：正文句内的「据公开资料显示」这类表述（属合规的就近标注）。

用法:
  python3 scripts/check_no_source_section.py output/drafts/xxx.md
  python3 scripts/check_no_source_section.py output/drafts/业务类3篇/
  python3 scripts/check_no_source_section.py --json output/drafts/xxx.md

退出码: 0 全部通过；1 存在来源章节。
"""
from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path

# 来源类章节名（出现在标题行或独立标签行即算违规）
SECTION_WORDS = (
    "资料来源", "数据来源", "参考来源", "信息来源", "引用来源", "参考文献",
    "参考资料", "来源说明", "核验说明", "资料与核验", "资料来源与核验说明",
    "数据与来源", "证据与来源", "来源账本",
)

# Markdown 标题行：## 资料来源 / ### 核验说明
HEADING_RE = re.compile(
    r"^\s{0,3}#{1,6}\s*\**\s*(?:" + "|".join(SECTION_WORDS) + r")"
)
# 加粗或纯文本标签行：**资料来源：** / 资料来源：
LABEL_RE = re.compile(
    r"^\s*(?:\*\*|\*|__)?\s*(?:" + "|".join(SECTION_WORDS) + r")\s*(?:\*\*|\*|__)?\s*[：:]"
)
# 引用块中的来源行：> 资料来源：
QUOTE_LABEL_RE = re.compile(
    r"^\s*>\s*(?:\*\*|\*)?\s*(?:" + "|".join(SECTION_WORDS) + r")\s*(?:\*\*|\*)?\s*[：:]"
)


def find_source_sections(text: str) -> list[dict]:
    """返回命中的来源章节位置。"""
    hits: list[dict] = []
    lines = text.splitlines()
    in_fence = False
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        # 跳过代码块
        if stripped.startswith("```"):
            in_fence = not in_fence
            continue
        if in_fence:
            continue
        for pattern, kind in (
            (HEADING_RE, "heading"),
            (QUOTE_LABEL_RE, "quote_label"),
            (LABEL_RE, "label"),
        ):
            if pattern.match(line):
                hits.append({
                    "line": i,
                    "kind": kind,
                    "text": stripped[:80],
                })
                break
    return hits


def check_file(path: Path) -> dict:
    text = path.read_text(encoding="utf-8")
    hits = find_source_sections(text)
    return {
        "path": str(path),
        "name": path.name,
        "hits": hits,
        "passed": not hits,
    }


def _iter_inputs(targets: list[str]) -> list[Path]:
    files: list[Path] = []
    for target in targets:
        p = Path(target)
        if p.is_dir():
            files.extend(sorted(p.glob("*.md")))
        elif p.is_file():
            files.append(p)
        else:
            print(f"[warn] 跳过不存在的路径: {target}", file=sys.stderr)
    return files


def main() -> int:
    ap = argparse.ArgumentParser(description="结尾来源章节核验")
    ap.add_argument("targets", nargs="*", help="Markdown 文件或目录")
    ap.add_argument("--json", action="store_true", help="输出 JSON")
    args = ap.parse_args()

    files = _iter_inputs(args.targets)
    if not files:
        print("未找到可检查的 Markdown 文件", file=sys.stderr)
        return 1

    results = [check_file(f) for f in files]

    if args.json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return 0 if all(r["passed"] for r in results) else 1

    failed = 0
    for r in results:
        print("=" * 62)
        status = "✓ PASS" if r["passed"] else "✗ FAIL"
        print(f"{r['name']}: {status}")
        for h in r["hits"]:
            print(f"  第 {h['line']} 行 [{h['kind']}] {h['text']}")
        if not r["passed"]:
            print("  => 结尾存在来源章节，请删除；数据出处改为正文句内就近标注")
            failed += 1

    print("=" * 62)
    print(f"合计 {len(files)} 篇：通过 {len(files) - failed} 篇，未通过 {failed} 篇")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
