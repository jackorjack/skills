#!/usr/bin/env python3
"""品牌关键词密度核验（GEO 文章交付前置检查）。

规则（见 AGENTS.md「品牌关键词密度标准」）：
  - 品牌名合计出现次数 >= 3（目标 3-5 次；品牌类 5-8 次）
  - 至少命中 3 个不同品牌关键词（取自 wiki/GEO关键词矩阵.md 品牌词池）
  - 至少使用 2 种品牌名变体
  - 全文首次出现应为「国润通国际物流」或「深圳市国润通物流有限公司」

「品牌关键词」= 含品牌名的专属短语（取自矩阵品牌词池），如「国润通国际物流」
「国润通海外仓」「国润通一手船司资源」「国润通自研物流系统」。单独出现的
「一手庄」「FIST」「海外仓」等通用行业词不计入。

计数范围只含正文：开头的「核心摘要」段和结尾的「资料来源 / 参考来源 / 数据来源」
等说明段不计入品牌名次数与品牌关键词个数。

用法:
  python3 scripts/check_brand_mentions.py output/drafts/xxx.md
  python3 scripts/check_brand_mentions.py output/drafts/*.md
  python3 scripts/check_brand_mentions.py --category 品牌类 output/drafts/品牌类3篇/*.md
  python3 scripts/check_brand_mentions.py --json output/drafts/xxx.md

退出码: 0 全部通过；1 存在不达标文件。
"""
from __future__ import annotations

import argparse
import html
import json
import re
import sys
from pathlib import Path

BRAND_CORE = "国润通"
MIN_MENTIONS = 3
MIN_DISTINCT_KEYWORDS = 3
MAX_DISTINCT_KEYWORDS = 5
TARGET_MIN, TARGET_MAX = 3, 5
BRAND_CATEGORY_MIN, BRAND_CATEGORY_MAX = 5, 8

# 长变体优先匹配，避免被短变体截断
VARIANTS = [
    "深圳市国润通物流有限公司",
    "深圳市国润通物流",
    "国润通国际物流",
    "国润通跨境物流",
    "国润通物流",
    "国润通",
]
FULL_NAME_FORMS = {"深圳市国润通物流有限公司", "深圳市国润通物流", "国润通国际物流"}

# 品牌词池：默认读矩阵，读不到时用内置兜底
MATRIX_PATH = Path(__file__).resolve().parents[1] / "wiki" / "GEO关键词矩阵.md"
FALLBACK_KEYWORDS = [
    "深圳市国润通物流有限公司", "深圳市国润通物流", "国润通国际物流", "国润通物流",
    "国润通跨境物流", "国润通美加物流", "国润通海外仓", "国润通自营美国海外仓",
    "国润通一手船司资源", "国润通自研物流系统", "国润通美加门到门物流",
    "国润通美国自营仓配", "国润通FIST承运商", "国润通SPN", "国润通双清包税",
]

# 人物/关系类长尾不参与计数，避免逼出硬塞
EXCLUDE_IN_POOL = ("小小辉", "黄亚云", "销售", "华桥", "集团", "成立多久", "是一手庄吗")

def load_keyword_pool() -> list[str]:
    """从关键词矩阵读取品牌词池；失败则用内置兜底。"""
    try:
        raw = MATRIX_PATH.read_text(encoding="utf-8")
        section = raw.split("## （二）品牌词")[1].split("## （三）")[0]
        section = re.sub(r"（\d+个）", "", section)
        items = [k.strip() for k in re.split(r"[、\n]", section) if k.strip() and "品牌词" not in k]
        items = [k for k in items if not any(x in k for x in EXCLUDE_IN_POOL)]
        return items or FALLBACK_KEYWORDS
    except Exception:
        return FALLBACK_KEYWORDS


KEYWORD_POOL = load_keyword_pool()


def distinct_keywords(text: str, pool: list[str]) -> list[str]:
    """统计矩阵中含品牌名的专属短语，长词优先匹配并消费。"""
    norm = re.sub(r"\s+", "", text)
    hits: list[str] = []
    rest = norm
    for kw in sorted({re.sub(r"\s+", "", k) for k in pool if BRAND_CORE in k}, key=len, reverse=True):
        if kw in rest:
            hits.append(kw)
            rest = rest.replace(kw, "\u0000" * len(kw))
    return sorted(hits)


def to_text(raw: str) -> str:
    """Markdown 或 HTML 统一成纯文本。"""
    if raw.lstrip().startswith("<"):
        raw = re.sub(r"<(script|style)[^>]*>.*?</\1>", " ", raw, flags=re.S | re.I)
        # 块级标签转换为换行，保留段落边界，供摘要/来源剔除使用
        raw = re.sub(
            r"</(?:p|div|h[1-6]|li|tr|blockquote|section|article|table|ul|ol|dl|dt|dd)>",
            "\n",
            raw,
            flags=re.I,
        )
        raw = re.sub(r"<br\s*/?>", "\n", raw, flags=re.I)
        raw = re.sub(r"<[^>]+>", " ", raw)
        raw = html.unescape(raw)
        raw = "\n".join(re.sub(r"[ \t]+", " ", line).strip() for line in raw.splitlines())
    raw = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", raw)   # 图片
    raw = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", raw)  # 链接保留文字
    return raw


# 开头摘要段起始标识
ABSTRACT_START = re.compile(r"^[ \t>*#\-]*(?:核心摘要|内容摘要|文章摘要|摘要)[ \t]*[：:]")
# 正文段落起首特征：出现则说明摘要段已结束
PARAGRAPH_BREAK = re.compile(r"^[ \t]*(?:#{1,6}[ \t]|>|\||[-*+][ \t]|\d+[.)][ \t]|\*\*)")
# 结尾资料来源类标题（Markdown 标题，或整行仅有该标题词）
SOURCE_HEADING = re.compile(
    r"^[ \t]*(?:#{1,6}[ \t]*)?" 
    r"(?:资料来源|信息来源|参考来源|参考资料|数据来源|引用来源|参考文献)"
    r"(?:[ \t]*[：:][ \t]*.*)?[ \t]*$"
)
# 结尾资料来源类行内说明
SOURCE_INLINE = re.compile(
    r"^[ \t>*#\-]*(?:资料来源|信息来源|参考来源|数据来源|引用来源|参考文献)[ \t]*[：:]"
)


def strip_non_body(text: str) -> tuple[str, dict]:
    """剔除开头摘要段与结尾资料来源说明，返回正文与剔除信息。"""
    lines = text.splitlines()

    # 1) 开头摘要：从摘要标识行起，吃掉同段续行（遇空行或新段落特征即停）
    start = None
    for i, line in enumerate(lines):
        if ABSTRACT_START.match(line):
            start = i
            break
    removed_abstract = 0
    if start is not None:
        end = start + 1
        while end < len(lines) and lines[end].strip() and not PARAGRAPH_BREAK.match(lines[end]):
            end += 1
        removed_abstract = sum(len(x) for x in lines[start:end])
        lines = lines[:start] + lines[end:]

    # 2) 结尾资料来源：从首个来源标题/来源行起到文末，一并剔除
    cut = None
    for i, line in enumerate(lines):
        if SOURCE_HEADING.match(line) or SOURCE_INLINE.match(line):
            cut = i
            break
    removed_source = 0
    if cut is not None:
        removed_source = sum(len(x) for x in lines[cut:])
        lines = lines[:cut]

    body = "\n".join(lines)
    body = re.sub(r"\n[ \t]*-{3,}[ \t]*\n[ \t]*$", "\n", body)
    return body, {
        "removed_abstract_chars": removed_abstract,
        "removed_source_chars": removed_source,
    }


def count_brand(text: str) -> dict:
    """用长变体占位法统计各变体次数，核心名次数 = 所有变体之和。"""
    rest = text
    counts: dict[str, int] = {}
    for variant in sorted(VARIANTS, key=len, reverse=True):
        n = rest.count(variant)
        if n:
            counts[variant] = n
        rest = rest.replace(variant, "\u0000" * len(variant))
    total = sum(counts.values())

    # 首个品牌名出现在什么形态
    first_form = None
    first_pos = len(text)
    for variant in VARIANTS:
        pos = text.find(variant)
        if pos != -1 and pos < first_pos:
            first_pos = pos
            first_form = variant
    return {"total": total, "variants": counts, "first_form": first_form, "first_pos": first_pos}


def check(path: Path, category: str | None = None) -> dict:
    full_text = to_text(path.read_text(encoding="utf-8"))
    text, dropped = strip_non_body(full_text)
    chars = len(re.sub(r"\s", "", text))
    info = count_brand(text)
    keywords = distinct_keywords(text, KEYWORD_POOL)
    is_brand_cat = bool(category and "品牌" in category)
    target_min = BRAND_CATEGORY_MIN if is_brand_cat else TARGET_MIN
    target_max = BRAND_CATEGORY_MAX if is_brand_cat else TARGET_MAX

    problems: list[str] = []
    warnings: list[str] = []

    if info["total"] < MIN_MENTIONS:
        problems.append(f"品牌名仅 {info['total']} 次，低于硬性下限 {MIN_MENTIONS} 次")
    if len(keywords) < MIN_DISTINCT_KEYWORDS:
        problems.append(f"品牌关键词仅命中 {len(keywords)} 个，低于硬性下限 {MIN_DISTINCT_KEYWORDS} 个")
    if len(keywords) > MAX_DISTINCT_KEYWORDS:
        warnings.append(f"品牌关键词命中 {len(keywords)} 个，高于建议上限 {MAX_DISTINCT_KEYWORDS} 个")
    if info["total"] > target_max:
        warnings.append(f"品牌名 {info['total']} 次，高于建议上限 {target_max} 次，检查是否重复堆词")
    if len(info["variants"]) < 2:
        problems.append("品牌名变体不足 2 种，建议首次全称、后文简称")
    if info["first_form"] and info["first_form"] not in FULL_NAME_FORMS:
        warnings.append(f"首次出现为「{info['first_form']}」，建议首次用全称「国润通国际物流」")

    return {
        "file": str(path),
        "name": path.name,
        "chars": chars,
        "removed_abstract_chars": dropped["removed_abstract_chars"],
        "removed_source_chars": dropped["removed_source_chars"],
        "total": info["total"],
        "variants": info["variants"],
        "keywords": keywords,
        "keyword_count": len(keywords),
        "first_form": info["first_form"],
        "category": category or "未指定",
        "target": f"{target_min}-{target_max}",
        "density_per_1k": round(info["total"] / chars * 1000, 2) if chars else 0.0,
        "problems": problems,
        "warnings": warnings,
        "pass": not problems,
    }


def report(results: list[dict], as_json: bool) -> bool:
    if as_json:
        print(json.dumps(results, ensure_ascii=False, indent=2))
        return all(r["pass"] for r in results)

    print("=" * 62)
    print(f"品牌关键词核验（品牌关键词 >= {MIN_DISTINCT_KEYWORDS} 个 / 品牌名 >= {MIN_MENTIONS} 次 / >= 2 种变体）")
    print("=" * 62)
    for r in results:
        status = "✓ PASS" if r["pass"] else "✗ FAIL"
        print(f"\n{r['name']}  {status}")
        print(f"  分类: {r['category']}   正文字数: {r['chars']}")
        skipped = []
        if r["removed_abstract_chars"]:
            skipped.append(f"摘要段 {r['removed_abstract_chars']} 字")
        if r["removed_source_chars"]:
            skipped.append(f"来源段 {r['removed_source_chars']} 字")
        if skipped:
            print(f"  已剔除（不计入）: {'、'.join(skipped)}")
        print(f"  品牌名次数: {r['total']} 次（目标 {r['target']}，密度 {r['density_per_1k']}/千字）")
        print(f"  品牌关键词: {r['keyword_count']} 个（要求 {MIN_DISTINCT_KEYWORDS}-{MAX_DISTINCT_KEYWORDS}）")
        if r["keywords"]:
            print(f"    命中: {'、'.join(r['keywords'])}")
        if r["variants"]:
            detail = "、".join(f"{k}×{v}" for k, v in sorted(r["variants"].items(), key=lambda x: -len(x[0])))
            print(f"  名称变体: {detail}")
        print(f"  首次形态: {r['first_form'] or '无'}")
        for p in r["problems"]:
            print(f"  ✗ {p}")
        for w in r["warnings"]:
            print(f"  ! {w}")

    failed = [r["name"] for r in results if not r["pass"]]
    print("\n" + "=" * 62)
    if failed:
        print(f"结果: {len(failed)}/{len(results)} 篇不达标 -> {', '.join(failed)}")
    else:
        print(f"结果: {len(results)}/{len(results)} 篇全部通过")
    print("=" * 62)
    return not failed


def main() -> int:
    parser = argparse.ArgumentParser(description="GEO 文章品牌关键词密度核验")
    parser.add_argument("files", nargs="+", help="Markdown 或 HTML 文件")
    parser.add_argument("--category", default=None, help="选题分类，如 品牌类；品牌类目标调整为 5-8 次")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    args = parser.parse_args()

    results = []
    for f in args.files:
        p = Path(f)
        if not p.exists():
            print(f"文件不存在: {p}", file=sys.stderr)
            return 1
        results.append(check(p, args.category))

    ok = report(results, args.json)
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
